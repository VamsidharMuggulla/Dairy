package com.dairy;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class GiveUpdate extends Activity {
	Spinner studen;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_give_update);

		
		InputStream is=null;
		
		/*Alerts alerts=new Alerts();
		boolean b=n.testNetwork();
		if(!b)
		{
			alerts.networkError(context);
			return false;
		}*/
		 try {
			 HttpClient httpclient = new DefaultHttpClient();
			 HttpPost httppost = new HttpPost("http://vamsidhar.esy.es/getstudents.php");
			 HttpResponse response = httpclient.execute(httppost);
			 HttpEntity entity = response.getEntity();
			 is = entity.getContent();
			
			 Log.e("log_tag", "getstudents.php success");
			 // Toast.makeText(getApplicationContext(), �pass�,Toast.LENGTH_SHORT).show();
			  } catch (Exception e) {
				  Log.e("log_tag", "getstudents.php failure" + e.toString());
				  //return false;				 					 
			  }
		//convert response to string
		  try {
		   BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"));
		  StringBuilder sb = new StringBuilder();
		 String line = null;
		  while ((line = reader.readLine()) != null) {
		  sb.append(line + "\n");
		  // Toast.makeText(getApplicationContext(), �Input Reading pass�, Toast.LENGTH_SHORT).show();
		  }
		  is.close();
		 
		 String result = sb.toString();
		  JSONArray jArray=new JSONArray(result);
		  
		  
			
		  JSONObject json_data ;
		  int x=0;
		  for(int i=0;i<jArray.length();i++)
		  {
			  json_data = jArray.getJSONObject(i);
			  
		      if(json_data.getString("studentname").length()!=0)
		      {
		    	  //students[i]=json_data.getString("studentname");
		    	x++;  
		      }
		      
		  }
		  String[] students=new String[x];
		  for(int i=0;i<x;i++)
		  {
			   json_data = jArray.getJSONObject(i);
			  students[i]=json_data.getString("studentname");
		  }
		  
		  
		  reader.close();
		  studen = (Spinner) findViewById(R.id.Students);
	        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
	                android.R.layout.simple_spinner_item,students);
	        studen.setAdapter(adapter);		  
		
		  //tv.setText(result);
		  } catch (Exception e) {
			  
		  Log.e("log_tag", "Error converting result" + e.toString());
		  				 
		  }	 

			final EditText et=(EditText)findViewById(R.id.update);
					
			Button b1=(Button)findViewById(R.id.send);
			b1.setOnClickListener(new OnClickListener() {
				
				@SuppressLint("NewApi")
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					String update=et.getText().toString();
					
					
					
					ArrayList<NameValuePair> al=new ArrayList<NameValuePair>();
					al.add(new BasicNameValuePair("update",update));
					al.add(new BasicNameValuePair("studentname",studen.getSelectedItem().toString()));
					Log.e("update : ",update); 


					InputStream is2 = null;
					// TODO Auto-generated method stub
					 try 
					 {
						
						 
						 HttpClient httpclient = new DefaultHttpClient();
						 HttpPost httppost = new HttpPost("http://vamsidhar.esy.es/giveupdate.php");
						 httppost.setEntity(new UrlEncodedFormEntity(al));
						 HttpResponse response = httpclient.execute(httppost);
						 HttpEntity entity = response.getEntity();
						  is2 = entity.getContent();
						 } catch (Exception e) 
						  {
						
							  Log.e("log_tag", "Error in http connection" + e.toString());
						  }
					 try 
					 {
						 BufferedReader br=new BufferedReader(new InputStreamReader(is2,"iso-8859-1"));
						 StringBuilder sb=new StringBuilder();
						 String line=null;
						 while((line=br.readLine())!=null)
							 sb.append(line+"\n");
						 is2.close();
						String result2=sb.toString();
						
						
						
						
						String x="true";
						//x=result2; != null;
						
						Log.e("res",""+result2.equals(false));
						
						Log.e("X==",""+x);
						if(result2.contains("false"))
						{
							x="false";
							Log.e("resulllllll",""+result2.equals(false));
							
							
						}
						
						 if(!x.equals("false"))
						 {
						 et.setText("");					
						 Log.e("FALSE","RESULT IS FALSE");
						 Toast.makeText(getApplicationContext(),"Update Sent Successfully", Toast.LENGTH_SHORT).show();
						 //Intent it=new Intent(GiveUpdate.this,Submitted.class);						 				 
						 //startActivity(it);
						 //finishAffinity();
						 finish();
					 }
						else
						{
							Log.e("FALSE","RESULT IS NOT FALSE");
							Toast.makeText(getApplicationContext(),"Unable To Send Update...\n Try after some time...", Toast.LENGTH_LONG).show();
						}
					 }
					 catch(Exception e) 
					 {
						 //x="false2";
						 Log.e("Exception String",e.toString());
						 Log.e("Exception Message",e.getMessage());
						 Log.e("Exception Cause",e.getCause().toString());
						 //Log.e("Exception StackTrace",e.printStackTrace());
						 
						 Log.e("log_tag","Error  in insert "+e.toString());
					}
			}
			
			

		
		});		
		}
	}
