package com.vam.hero.core;

/**
 * Marker class for resuming a timer through Otto
 */
public class ResumeTimerEvent {
}
