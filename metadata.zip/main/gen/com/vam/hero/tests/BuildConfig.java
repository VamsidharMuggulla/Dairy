/** Automatically generated file. DO NOT MODIFY */
package com.vam.hero.tests;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}