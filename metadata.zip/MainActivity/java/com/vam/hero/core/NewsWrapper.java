package com.vam.hero.core;


import java.util.List;

public class NewsWrapper {
    private List<News> results;

    public List<News> getResults() {
        return results;
    }
}
