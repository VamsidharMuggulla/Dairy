package com.vam.hero.core;

/**
 * Marker class for the stop timer event in Otto.
 */
public class StopTimerEvent {
}
