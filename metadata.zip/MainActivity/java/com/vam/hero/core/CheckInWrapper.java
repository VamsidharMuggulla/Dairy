package com.vam.hero.core;

import java.util.List;

public class CheckInWrapper {
    private List<CheckIn> results;

    public List<CheckIn> getResults() {
        return results;
    }
}
